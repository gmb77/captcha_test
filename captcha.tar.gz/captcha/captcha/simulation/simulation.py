#!/bin/python3

import os

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
import pickle
import tensorflow.keras as ker
from imageprocessor import process_set
from trainer import do_training
from solver import do_prediction
from solver import rename_to_prediction

new_size = (20, 20)
model_file = "model.hdf5"
label_file = "labels.dat"
train_dirs = {
    "images": "../train_set",
    "output": "train_data/letters",
    "ignored": "train_data/ignored"
}
test_dirs = {
    "images": "../test_set",
    "output": "test_data/letters",
    "ignored": "test_data/ignored"
}

print()
print("Training and test sets' preprocessing ...")
# Preprocess train and test sets: save extracted letters, handle not recognised (ignored) images
process_set(train_dirs)
process_set(test_dirs)

labels = sorted(os.listdir(train_dirs["output"]))

# Save labels
with open(label_file, "wb") as file:
    pickle.dump(labels, file)

print()
print("Neural network training ...")
# Train neural network and save model parameters
do_training(train_dirs["output"], model_file, new_size, len(labels))

print()
print("Validation ...")
# Fetch validating set and load model
validating_set = ker.preprocessing.image_dataset_from_directory(
    test_dirs["output"], image_size=new_size, label_mode="categorical", color_mode="grayscale", shuffle=True)
model = ker.models.load_model(model_file)

# Validate test set
model.evaluate(validating_set)

# Load labels and model
with open(label_file, "rb") as file:
    labels = pickle.load(file)
model = ker.models.load_model(model_file)

print()
print("Captcha prediction ...")
# Predicate test set (batch mode)
do_prediction(test_dirs["images"], model, labels, (20, 20), batch_size=256)

print()
print("Rename captcha to prediction ...")
image_name = os.listdir(test_dirs["images"])[0]
init_name = "unpredicted.png"
os.system("cp {} {}".format(os.path.join(os.path.relpath(test_dirs["images"]), image_name), init_name))
rename_to_prediction(os.path.join(os.path.relpath("."), init_name), model, labels, new_size)
if not os.path.isfile(init_name) and os.path.isfile(image_name):
    print("Captcha is renamed to the correct text.")
else:
    print("Could not rename captcha properly.")
