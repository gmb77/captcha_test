After archive extraction, you should run:
./install

After installation, you should go to the installation folder (as installation instructed) and run:
./run

For uninstallation, you should run from source folder:
./uninstall
